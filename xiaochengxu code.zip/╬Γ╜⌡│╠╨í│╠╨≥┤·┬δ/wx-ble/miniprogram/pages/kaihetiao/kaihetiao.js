// pages/kaihetiao/kaihetiao.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database({ env: 'prod1-rt3l3' });
const accelerometerDB = db.collection('movement3')
let accXs = [];
let accYs = [];
let accZs = [];
let gyrXs = [];
let gyrYs = [];
let gyrZs = [];
let timeSs = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    value: 0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs: [],
    gyrYs: [],
    gyrZs: [],
    timeSs: [],
    startTime: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("获取加速度计数据");
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("调用成功"); },
      fail: res => { console.log(res) }
    })
    wx.startGyroscope({
      interval: 'game',
      success: res => {
        console.log("调用成功");
      }
    });
  },

  startAccelerometer: function (e) {
    var m = 0
    this.setData({ startTime: new Date().getTime() })
    let _this = this;
    _this.setData({ isReading: true })
    setTimeout(function () {
      console.log("stop")
      wx.offAccelerometerChange()
      wx.offGyroscopeChange()
    }, 10000)
    // wx.startAccelerometer({
    //   interval: 'game',
    //   success() {
    //     console.log("调用成功");
    wx.onAccelerometerChange(function (res) {
      m = m + 1;
      console.log(m)
      let mid_time = new Date().getTime();
      console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
      // console.log(res.x, res.y, res.z, mid_time )
      let timeStep = (mid_time - _this.data.startTime) / 1000
      _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep) });
      accXs.push(res.x)
      accYs.push(res.y)
      accZs.push(res.z)
      timeSs.push(mid_time)
      _this.setData({
        accelerometerX: parseFloat(res.x.toFixed(5)),
        accelerometerY: parseFloat(res.y.toFixed(5)),
        accelerometerZ: parseFloat(res.z.toFixed(5))
      })
    })
    //   }
    // })
    // wx.startGyroscope({
    //   interval: 'game',
    //   success() {
    //     console.log("调用成功");
    wx.onGyroscopeChange(function (res1) {

      // console.log("timeStep < 10")
      gyrXs.push(res1.x)
      gyrYs.push(res1.y)
      gyrZs.push(res1.z)
      _this.setData({
        gyroscopeX: parseFloat(res1.x.toFixed(5)),
        gyroscopeY: parseFloat(res1.y.toFixed(5)),
        gyroscopeZ: parseFloat(res1.z.toFixed(5))
      })
    })
    //   }
    // })

    _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs, timeSs: timeSs })
  },
  // 监听加速度数据
  // wx.onAccelerometerChange(function (res) {
  //   let mid_time = new Date().getTime();
  //  console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
  //   console.log(res.x, res.y, res.z, mid_time )
  //   let timeStep = (mid_time - _this.data.startTime) / 1000
  //   _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
  //   if (timeStep < 10) {
  //     console.log("timeStep < 10")
  //     accXs.push(res.x)
  //     accYs.push(res.y)
  //     accZs.push(res.z)
  //     timeSs.push(mid_time)
  //     _this.setData({
  //       accelerometerX: parseFloat(res.x.toFixed(5)),
  //       accelerometerY: parseFloat(res.y.toFixed(5)),
  //       accelerometerZ: parseFloat(res.z.toFixed(5)),
  //     })
  //   } 
  //   if (timeStep >= 10) {
  //     console.log("timeStep = 10")
  //     _this.setData({ value: 100, displayValue: 10});
  //     _this.stopAccelerometer();
  //    wx.stopGyroscope();
  //     console.log("end-time: ", Date.now())
  //     _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, timeSs: timeSs })
  //     return;
  //   }
  // })
  // },
  // num: function (e) {
  //   this.setData({
  //     inputValue: e.detail.value
  //   })
  //   console.log(this.data.inputValue)
  // },
  stopAccelerometer: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },
  num: function (e) {
    console.log("save...")
    var num = e.detail.value.num;
    console.log(num);
    var height = wx.getStorageSync('height')
    var age = wx.getStorageSync('age')
    var sex = wx.getStorageSync('sex')
    //console.log(height)
    accelerometerDB.add({
      data: { accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs, num: num, height: height, age: age, sex: sex, timeSs: timeSs }
    })
      .then(res => {
        console.log("保存成功");
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // console.log("获取加速度计数据");
    // wx.startAccelerometer({
    //   interval: 'game',
    //   success: res => { console.log("调用成功"); },
    //   fail: res => { console.log(res) }
    // })
    // wx.startGyroscope({
    //   interval: 'game',
    //   success: res => {
    //     console.log("调用成功");
    //   }
    // });

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})