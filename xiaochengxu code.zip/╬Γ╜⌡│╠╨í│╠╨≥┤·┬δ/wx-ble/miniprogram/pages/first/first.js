// pages/first/first.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array1: ['150以下', '151-155', '156-160', '161-165', '166-170', '171-175', '176-180', '181-185','186-190','190以上'],
    objectArray1: [
      {
        id: 0,
        name: '150以下'
      },
      {
        id: 1,
        name: '151-155'
      },
      {
        id: 2,
        name: '156-160'
      },
      {
        id: 3,
        name: '161-165'
      },
      {
        id: 4,
        name: '166-170'
      },
      {
        id: 5,
        name: '171-175'
      },
      {
        id: 6,
        name: '176-180'
      },
      {
        id: 7,
        name: '181-185'
      },
      {
        id: 8,
        name: '186-190'
      },
      {
        id: 9,
        name: '190以上'
      }

    ],
    index1: 0,
    array2: ['15以下', '16-25', '26-35', '36-45', '46-55', '55以上'],
    objectArray2: [
      {
        id: 0,
        name: '15以下'
      },
      {
        id: 1,
        name: '16-25'
      },
      {
        id: 2,
        name: '26-35'
      },
      {
        id: 3,
        name: '36-45'
      },
      {
        id: 4,
        name: '46-55'
      },
      {
        id: 5,
        name: '55以上'
      }

    ],
    index2: 0,
    array3: ['男', '女'],
    objectArray3: [
      {
        id: 0,
        name: '男'
      },
      {
        id: 1,
        name: '女'
      }

    ],
    index3: 0,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  bindPickerChange1: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index1: e.detail.value
    })
    wx.setStorageSync('height', e.detail.value)
  },
    bindPickerChange2: function (e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        index2: e.detail.value
      })
      wx.setStorageSync('age', e.detail.value)
  },
  bindPickerChange3: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index3: e.detail.value
    })
    wx.setStorageSync('sex', e.detail.value)
  },
  cepingju:function(e){
    wx.request({
      url: 'http://175.24.73.120:5000',
      method: 'post',
      data: [1.0739448026884224, -0.08621664778152922, 0.5854656019734074, 0.5546010909342829, 0.37335625843764336, 0.4872368430901642, 1.0109161758601066, 0.41735737146214175, 0.7183301457553797, 0.7043481901303328, 0.1312217572720157, 0.12503162674742563, 1.0109161758601066, 0.41735737146214175, 0.7183301457553797, 0.7043481901303328, 0.1312217572720157, 0.12503162674742563, 0.7131201118431167, -1.178812105141892, -0.025620277395348653, -0.13621795079996524, 0.5917971786614279, 0.7542555701131674, 2.194553206015991, -3.299457597869177, -0.5306853326122298, -0.35645542968263033, 1.358307887429624, 1.7045352412221395, 0.2613962080274986, -1.9019683534057374, -0.19067140023047024, -0.30210443144701427, 0.392464957139025, 0.3733886231179807],
      success: res => {
        console.log(res.data)
      }
    })
    wx.navigateTo({
      url: '../cepingju/cepingju',
    })
  },
  jiaochapao: function (e) {
    wx.navigateTo({
      url: '../jiaochapao/jiaochapao',
    })
  },
  kaihetiao: function (e) {
    wx.navigateTo({
      url: '../kaihetiao/kaihetiao',
    })
  },
  bandun: function (e) {
    wx.navigateTo({
      url: '../bandun/bandun',
    })
  }
})