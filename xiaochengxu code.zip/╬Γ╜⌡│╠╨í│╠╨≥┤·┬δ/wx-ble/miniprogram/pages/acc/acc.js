// pages/acc/acc.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database({ env: 'prod1-rt3l3' });
const accelerometerDB = db.collection('movement1')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    value: 0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs:[],
    gyrYs:[],
    gyrZs:[],
    timeSs: [],
    startTime: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log("获取加速度计数据");
    // wx.startAccelerometer({
    //   interval: 'game',
    //   success: res => { console.log("调用成功"); },
    //   fail: res => { console.log(res) }
    // })
    // wx.startGyroscope({
    //   interval: 'game',
    //   success: res => {
    //     console.log("调用成功");
    //   }
    // });
  },

  startAccelerometer: function (e) {
    this.setData({ startTime: new Date().getTime()})
    let _this = this;
    _this.setData({ isReading: true })
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let gyrXs=[];
    let gyrYs = [];
    let gyrZs = [];
    let timeSs = [];
      setTimeout(function () {
        console.log("stop")
        wx.offAccelerometerChange()
        wx.offGyroscopeChange()},10000)
        wx.startAccelerometer({
        interval: 'game',
        success(){
        console.log("调用成功");
        wx.onAccelerometerChange(function (res) {
          let mid_time = new Date().getTime();
          console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
          // console.log(res.x, res.y, res.z, mid_time )
          let timeStep = (mid_time - _this.data.startTime) / 1000
          _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep) });
        accXs.push(res.x)
        accYs.push(res.y)
        accZs.push(res.z)
        _this.setData({
          accelerometerX: parseFloat(res.x.toFixed(5)),
          accelerometerY: parseFloat(res.y.toFixed(5)),
          accelerometerZ: parseFloat(res.z.toFixed(5))
        })
      })
    }})
      wx.startGyroscope({
        interval: 'game',
        success() {
          console.log("调用成功");
      wx.onGyroscopeChange(function (res1) {
        // console.log("timeStep < 10")
        gyrXs.push(res1.x)
        gyrYs.push(res1.y)
        gyrZs.push(res1.z)
        _this.setData({
          gyroscopeX: parseFloat(res1.x.toFixed(5)),
          gyroscopeY: parseFloat(res1.y.toFixed(5)),
          gyroscopeZ: parseFloat(res1.z.toFixed(5))
        })
      })
    }})

    _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs })
},
    // 监听加速度数据
    // wx.onAccelerometerChange(function (res) {
    //   let mid_time = new Date().getTime();
    //  console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
    //   console.log(res.x, res.y, res.z, mid_time )
    //   let timeStep = (mid_time - _this.data.startTime) / 1000
    //   _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
    //   if (timeStep < 10) {
    //     console.log("timeStep < 10")
    //     accXs.push(res.x)
    //     accYs.push(res.y)
    //     accZs.push(res.z)
    //     timeSs.push(mid_time)
    //     _this.setData({
    //       accelerometerX: parseFloat(res.x.toFixed(5)),
    //       accelerometerY: parseFloat(res.y.toFixed(5)),
    //       accelerometerZ: parseFloat(res.z.toFixed(5)),
    //     })
    //   } 
    //   if (timeStep >= 10) {
    //     console.log("timeStep = 10")
    //     _this.setData({ value: 100, displayValue: 10});
    //     _this.stopAccelerometer();
    //    wx.stopGyroscope();
    //     console.log("end-time: ", Date.now())
    //     _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, timeSs: timeSs })
    //     return;
    //   }
    // })
 // },

  stopAccelerometer: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopAccelerometer({
      success: res => {
        console.log("停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },
  saveAcc() {
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, gyrXs = this.data.gyrXs, gyrYs = this.data.gyrYs, gyrZs = this.data.gyrZs;
    accelerometerDB.add({
      data: { accXs: accXs, accYs: accYs, accZs: accZs, gyrXs: gyrXs, gyrYs: gyrYs, gyrZs: gyrZs }
    })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") })
  },
  takePhoto: function() {
    let _this = this
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        const tempFilePaths = res.tempFilePaths
        _this.setData({
          tmpImg: tempFilePaths,
        })
      }
    })
  },

  saveImg: function() {
    let filePath = this.data.tmpImg[0];
    let suffix = /\.[^\.]+$/.exec(filePath)[0];
    wx.cloud.uploadFile({
      cloudPath: "Camera/" + new Date().getTime() + suffix,
      filePath: filePath,
      config: { env: 'prod-xyfg7' }
    }).then(res => {
      console.log(res);
      this.setData({ fileIDs: res.fileID, tmpImg: null});
      wx.showToast({
        title: '保存成功',
      })
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})