// pages/reco/reco.js
var m=0;
const app = getApp()
//获取数据库引用
const db = wx.cloud.database({
  env: 'prod1-rt3l3'
});

var interval = null //先在全局定义定时器
Page({

  /**
   * 页面的初始数据
   */
  data: {
    capsuleInfo: app.globalData.capsuleInfo,
    value: 0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    num1:Number,
    num2:Number,
    num3:Number,
    num4:Number,
    getnumber:false,
    allYs:[],
    accXs: [],
    accYs: [],
    accZs: [],
    gyrXs: [],
    gyrYs: [],
    gyrZs: [],
    timeSs: [],
    begin:false,
    startTime: 0,
    active:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

   
  },

 /** startAccelerometer: function(e) {
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let gyrXs = [];
    let gyrYs = [];
    let gyrZs = [];
    let _this = this;
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.autoplay = true // 是否自动开始播放，默认为 false
    innerAudioContext.loop = false // 是否循环播放，默认为 false
    wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
      obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
      success: function(e) {
        //console.log(e)
        console.log('play success')
      },
      fail: function(e) {
        console.log(e)
        console.log('play fail')
      }
    })
    innerAudioContext.src = 'MP3/测试开始.m4a'; // 音频资源的地址
    innerAudioContext.onPlay(() => { // 监听音频播放事件
      console.log('开始进行运动')
    })
    innerAudioContext.onError((res) => { // 监听音频播放错误事件
      console.log(res.errMsg)
      console.log(res.errCode)
    })
    this.setData({
      startTime: new Date().getTime(), 
      text:'停止'
    })

    /**setTimeout(function () {
     // var startTime=new Date().getTime();
      //_this.setData({ fisttime: startTime})
      wx.onAccelerometerChange(function(res) {
      wx.onGyroscopeChange(function(res1) {
        //let mid_time = new Date().getTime();
       // console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
        // console.log(res.x, res.y, res.z, mid_time )
        //let timeStep = (mid_time - startTime) / 1000
        //_this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
       // m = m + 1;
       // console.log(timeStep)
          accXs.push(res.x)
          accYs.push(res.y)
          accZs.push(res.z)
          gyrXs.push(res1.x)
          gyrYs.push(res1.y)
          gyrZs.push(res1.z)
          //timeSs.push(mid_time)
          _this.setData({
            accelerometerX: parseFloat(res.x.toFixed(5)),
            accelerometerY: parseFloat(res.y.toFixed(5)),
            accelerometerZ: parseFloat(res.z.toFixed(5)),
            gyroscopeX: parseFloat(res1.x.toFixed(5)),
            gyroscopeY: parseFloat(res1.y.toFixed(5)),
            gyroscopeZ: parseFloat(res1.z.toFixed(5))
          })
        })})
      },3000)
      this.setData({ startTime: new Date().getTime()})
      setInterval(function(){
          //var gyrZs = JSON.stringify(gyrZs);
          wx.onAccelerometerChange(function(res) {
            wx.onGyroscopeChange(function(res1) {
              let mid_time = new Date().getTime();
              //let timeStep = (mid_time - _this.data.startTime) 
              if(accXs.length<=250){
              //let mid_time = new Date().getTime();
             // console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
              // console.log(res.x, res.y, res.z, mid_time )
              //let timeStep = (mid_time - startTime) / 1000
              //_this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
             // m = m + 1;
             // console.log(timeStep)
                accXs.push(res.x)
                accYs.push(res.y)
                accZs.push(res.z)
                gyrXs.push(res1.x)
                gyrYs.push(res1.y)
                gyrZs.push(res1.z)
                //timeSs.push(mid_time)
             /**   _this.setData({
                  accelerometerX: parseFloat(res.x.toFixed(5)),
                  accelerometerY: parseFloat(res.y.toFixed(5)),
                  accelerometerZ: parseFloat(res.z.toFixed(5)),
                  gyroscopeX: parseFloat(res1.x.toFixed(5)),
                  gyroscopeY: parseFloat(res1.y.toFixed(5)),
                  gyroscopeZ: parseFloat(res1.z.toFixed(5))
                }) 
              }
              else {
                //_this.setData({ startTime: new Date().getTime()})
                wx.offAccelerometerChange()
                wx.offGyroscopeChange()
                console.log(gyrXs.length)
                wx.request({
            url: 'http://175.24.73.120:5000',
            method: 'post',
            data: {
                gyrXs: gyrXs,
                gyrYs: gyrYs,
                gyrZs: gyrZs, 
                accXs: accXs,
                accYs: accYs,
                accZs: accZs
                },//注意这里哈！   
            header: {
              "Content-Type": "application/x-www-form-urlencoded" //用于post
            },
            success: res => {
              accXs=[];
              accYs=[];
              accZs=[];
              gyrZs=[];
              gyrXs=[];
              gyrYs=[];
              
             // console.log(res.data[1])
              if (res.data[1] == 1) {
                innerAudioContext.src = "MP3/徒手侧平举.m4a"; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为侧平举')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 2) {
                innerAudioContext.src = "MP3/前后交叉小跑.m4a"; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为前后交叉小跑')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 3) {
                innerAudioContext.src = "MP3/开合跳.m4a"; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为开合跳')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 4) {
                innerAudioContext.src = "MP3/半蹲.m4a"; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为半蹲')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
            },
            fail:res=>{
              console.log("访问服务器失败了")
            }
          })}
        })})},5050)
      },
   

* ****/
/**startAccelerometer: function(e) {
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let gyrXs = [];
    let gyrYs = [];
    let gyrZs = [];
    let _this = this;
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.autoplay = true // 是否自动开始播放，默认为 false
    innerAudioContext.loop = false // 是否循环播放，默认为 false
    wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
      obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
      success: function(e) {
        //console.log(e)
        console.log('play success')
      },
      fail: function(e) {
        console.log(e)
        console.log('play fail')
      }
    })
    innerAudioContext.src = 'MP3/测试开始.m4a'; // 音频资源的地址
    innerAudioContext.onPlay(() => { // 监听音频播放事件
      console.log('开始进行运动')
    })
    innerAudioContext.onError((res) => { // 监听音频播放错误事件
      console.log(res.errMsg)
      console.log(res.errCode)
    })
    this.setData({
      startTime: new Date().getTime(), 
      text:'停止'
    })
    //_this.start()
    wx.startAccelerometer({
      interval: 'game',
      success: res => {
        console.log("调用成功");
      },
      fail: res => {
        console.log(res)
      }
    })
    wx.startGyroscope({
      interval: 'game',
      success: res => {
        console.log("调用成功");
      }
    });
    wx.onAccelerometerChange(function (res) {
      let mid_time = new Date().getTime();
      let timeStep = (mid_time - _this.data.startTime) / 1000
      if(timeStep < 2.56) {
        accXs.push(res.x)
        accYs.push(res.y)
        accZs.push(res.z)
       // timeSs.push(mid_time)
      }
    }) 
    wx.onGyroscopeChange(function (res) {
      let mid_time = new Date().getTime();
      let timeStep = (mid_time - _this.data.startTime) / 1000
      if(timeStep < 2.56) {
        gyrXs.push(res.x)
        gyrYs.push(res.y)
        gyrZs.push(res.z)
      }
      else {
        _this.setData({
          startTime: new Date().getTime(),
          accXs: accXs, 
          accYs: accYs, 
          accZs: accZs, 
          gyrXs: gyrXs,
          gyrYs: gyrYs,
          gyrZs: gyrZs,
         // timeSs: timeSs
        })
       // console.log(_this.data.accZs)
        accXs = []
        accYs = []
        accZs = []
        gyrXs = []
        gyrYs = []
        gyrZs = []
        wx.request({
          url: 'http://175.24.73.120:5000', //仅为示例，并非真实的接口地址
          data: {
          gyrXs: _this.data.gyrXs,
          gyrYs: _this.data.gyrYs,
          gyrZs: _this.data.gyrZs,
          accXs: _this.data.accXs,
          accYs: _this.data.accYs,
          accZs: _this.data.accZs
          },
          method:'POST',
          header: {
            'content-type': 'application/json' // 默认值
          },
          success (res) {
            console.log(res.data[1])
              if (res.data[1] == 1) {
                innerAudioContext.src = 'MP3/徒手侧平举.m4a'; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为侧平举')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 2) {
                innerAudioContext.src = 'MP3/前后交叉小跑.m4a'; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为前后交叉小跑')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 3) {
                innerAudioContext.src = 'MP3/开合跳.m4a'; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为开合跳')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
              else if (res.data[1] == 4) {
                innerAudioContext.src = 'MP3/半蹲.m4a'; // 音频资源的地址

                innerAudioContext.onPlay(() => { // 监听音频播放事件
                  console.log('播报动作为半蹲')
                })
                innerAudioContext.onError((res) => { // 监听音频播放错误事件
                  console.log(res.errMsg)
                  console.log(res.errCode)
                })
              }
          }
        })
    }
  })
}, **/
startAccelerometer: function(e) {
 
  let accXs = [];
  let accYs = [];
  let accZs = [];
  let gyrXs = [];
  let gyrYs = [];
  let gyrZs = [];
  let allYs=[];
  let array=[];
  let _this = this;
  if(_this.data.begin == false){
  _this.setData({
    getnumber:false,
    begin:true

  })
  const innerAudioContext = wx.createInnerAudioContext()
  innerAudioContext.autoplay = true // 是否自动开始播放，默认为 false
  innerAudioContext.loop = false // 是否循环播放，默认为 false
  wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
  obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
  success: function(e) {
  //console.log(e)
  console.log('play success')
  },
  })
  innerAudioContext.src = 'MP3/测试开始.m4a'; // 音频资源的地址
  innerAudioContext.onPlay(() => { // 监听音频播放事件
  console.log('播报开始运动')
  })

 






  




  //this.start()
setTimeout(function (params) {
  

  wx.startAccelerometer({
    interval: 'game',
    success: res => {
    console.log("加速度计调用成功");
    wx.onAccelerometerChange(function (res) {
      accXs.push(res.x) 
      accYs.push(res.y)
      accZs.push(res.z)
    }) 
    },
    })
    wx.startGyroscope({
    interval: 'game',
    success: res => {
    console.log("陀螺仪调用成功");
    wx.onGyroscopeChange(function (res) {     
      gyrXs.push(res.x)
      gyrYs.push(res.y)
      gyrZs.push(res.z)
  }) 
    }
    });


_this.setData({
  truetime:new Date().getTime(), 
  startTime: new Date().getTime(), 
  })


 

  interval=setInterval(function(){
  let mid_time = new Date().getTime();
  let stopStep=(mid_time-_this.data.truetime)/1000
  allYs=allYs.concat(accYs)
  if(stopStep<=30){
  console.log(accYs)
    // console.log(this.data.accZs)
    wx.request({
      url: 'https://www.wjccloud.cn:5000',//这里为我申请的端口号。 
      data: {
         gyrXs: gyrXs,
         gyrYs: gyrYs, 
         gyrZs: gyrZs, 
         accXs: accXs,
         accYs: accYs, 
         accZs: accZs
        },
         method:'POST', 
         success (res) {
            //allYs=allYs.concat(accYs)
            accXs = [] 
            accYs = [] 
            accZs = [] 
            gyrXs = [] 
            gyrYs = [] 
            gyrZs = [] 
            console.log(res.data[1]) 
            array.push(res.data[1])
            if (res.data[1] == 1) {
              _this.setData({
                active:"徒手侧平举"
              })
               innerAudioContext.src = 'MP3/徒手侧平举.m4a'; 
               innerAudioContext.onPlay(() => {
                  console.log('播报动作为侧平举') }) }
            else if (res.data[1] == 2) {
              _this.setData({
                active:"前后交叉小跑"
              })
                    innerAudioContext.src = 'MP3/前后交叉小跑.m4a'; 
                    innerAudioContext.onPlay(() => { 
                      console.log('播报动作为前后交叉小跑') })}
            else if (res.data[1] == 3) { 
              _this.setData({
                active:"开合跳"
              })
                    innerAudioContext.src = 'MP3/开合跳.m4a'; 
                    innerAudioContext.onPlay(() => {
                       console.log('播报动作为开合跳') })}
            else if (res.data[1] == 4) { 
              _this.setData({
                active:"半蹲"
              })
              innerAudioContext.src = 'MP3/半蹲.m4a';
             innerAudioContext.onPlay(() => {
            console.log('播报动作为半蹲') })
   } }
   })
  }
  
  else{
    clearInterval(interval);

    wx.offAccelerometerChange()
    wx.offGyroscopeChange()
  setTimeout(function(e){
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.autoplay = true // 是否自动开始播放，默认为 false
    innerAudioContext.loop = false // 是否循环播放，默认为 false
    wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
    obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
    success: function(e) {
    //console.log(e)
    console.log('play success')
    },
    })
    innerAudioContext.src = 'MP3/识别完成.m4a'; // 音频资源的地址
    innerAudioContext.onPlay(() => { // 监听音频播放事件
    console.log('播报停止运动')
    })
  },1500)
    wx.request({
      url: 'https://www.wjccloud.cn:5000',//这里为我申请的端口号。 
      data: {
         gyrXs: gyrXs,
         gyrYs: gyrYs, 
         gyrZs: gyrZs, 
         accXs: accXs,
         accYs: accYs, 
         accZs: accZs
        },
         method:'POST', 
         success (res) { 
          array.push(res.data[1])
          if (res.data[1] == 1) {
            _this.setData({
              active:"徒手侧平举"
            })
             innerAudioContext.src = 'MP3/徒手侧平举.m4a'; 
             innerAudioContext.onPlay(() => {
                console.log('播报动作为侧平举') }) }
          else if (res.data[1] == 2) {
            _this.setData({
              active:"前后交叉小跑"
            })
                  innerAudioContext.src = 'MP3/前后交叉小跑.m4a'; 
                  innerAudioContext.onPlay(() => { 
                    console.log('播报动作为前后交叉小跑') })}
          else if (res.data[1] == 3) { 
            _this.setData({
              active:"开合跳"
            })
                  innerAudioContext.src = 'MP3/开合跳.m4a'; 
                  innerAudioContext.onPlay(() => {
                     console.log('播报动作为开合跳') })}
          else if (res.data[1] == 4) { 
            _this.setData({
              active:"半蹲"
            })
            innerAudioContext.src = 'MP3/半蹲.m4a';
           innerAudioContext.onPlay(() => {
          console.log('播报动作为半蹲') })
 }
     wx.request({
      url: 'https://www.wjccloud.cn:5000/123',//这里为我申请的端口号。 
      data: {
        allYs:allYs,
        array:array,
      },
       method:'POST', 
       // header: { // 'content-type': 'application/json' // 默认值 // }, 
       success (res) {
         console.log(res.data)
         

         _this.setData({
           getnumber:true,
           num1:Number(res.data[0]),
           num2:Number(res.data[1]),
           num3:Number(res.data[2]),
           num4:Number(res.data[3])
         })
 } })
  }
   })   
    return;

   }
  },2000)
},1500)

}

 },





  stopAccelerometer: function() {
    let _this=this;
    wx.stopAccelerometer({
      complete: (res) => {console.log("停止了")},
    })
    wx.stopGyroscope({
      complete: (res) => {console.log("陀螺仪也停了")},
    })
    wx.offAccelerometerChange()
    wx.offGyroscopeChange()
    _this.setData({
      getnumber:false,
      begin:false
    })
    const innerAudioContext = wx.createInnerAudioContext()
    innerAudioContext.autoplay = true // 是否自动开始播放，默认为 false
    innerAudioContext.loop = false // 是否循环播放，默认为 false
    wx.setInnerAudioOption({ // ios在静音状态下能够正常播放音效
      obeyMuteSwitch: false, // 是否遵循系统静音开关，默认为 true。当此参数为 false 时，即使用户打开了静音开关，也能继续发出声音。
      success: function(e) {
        //console.log(e)
        console.log('play success')
      },
    })
    innerAudioContext.src = 'MP3/识别完成.m4a'; // 音频资源的地址
    innerAudioContext.onPlay(() => { // 监听音频播放事件
    console.log('播报停止运动')
})
 clearInterval(interval);
  },
  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    wx.stopAccelerometer()
    wx.stopGyroscope()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    wx.stopAccelerometer()
    wx.stopGyroscope()
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})